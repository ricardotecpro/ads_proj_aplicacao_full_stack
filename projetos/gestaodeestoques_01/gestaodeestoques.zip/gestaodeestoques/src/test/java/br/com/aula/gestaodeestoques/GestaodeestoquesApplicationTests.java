package br.com.aula.gestaodeestoques;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GestaodeestoquesApplicationTests {

	@Test
	void contextLoads() {
	}

}
