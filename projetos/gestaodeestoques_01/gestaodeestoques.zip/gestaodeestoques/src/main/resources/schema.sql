    -- Remover tabelas existentes para garantir um estado limpo
    DROP TABLE IF EXISTS produto;
    DROP TABLE IF EXISTS categoria;
    DROP TABLE IF EXISTS fornecedor;
    DROP TABLE IF EXISTS usuario_papel;
    DROP TABLE IF EXISTS usuario;
    DROP TABLE IF EXISTS papel;

    -- Tabela de Categorias
    CREATE TABLE categoria (
        id INT AUTO_INCREMENT PRIMARY KEY,
        nome VARCHAR(100) NOT NULL UNIQUE
    );

    -- Tabela de Fornecedores
    CREATE TABLE fornecedor (
        id INT AUTO_INCREMENT PRIMARY KEY,
        nome VARCHAR(100) NOT NULL,
        cnpj VARCHAR(18) NOT NULL UNIQUE
    );

    -- Tabela de Usuários (COM A COLUNA "ATIVO")
    CREATE TABLE usuario (
        id BIGINT AUTO_INCREMENT PRIMARY KEY,
        login VARCHAR(100) NOT NULL UNIQUE,
        senha VARCHAR(255) NOT NULL,
        ativo BOOLEAN NOT NULL DEFAULT TRUE
    );

    -- Tabela de Papéis (Roles/Permissions)
    CREATE TABLE papel (
        id BIGINT AUTO_INCREMENT PRIMARY KEY,
        nome VARCHAR(100) NOT NULL UNIQUE -- Ex: ROLE_ADMIN, ROLE_USER
    );

    -- Tabela de Junção para o relacionamento N-N entre Usuário e Papel
    CREATE TABLE usuario_papel (
        usuario_id BIGINT NOT NULL,
        papel_id BIGINT NOT NULL,
        PRIMARY KEY (usuario_id, papel_id),
        FOREIGN KEY (usuario_id) REFERENCES usuario(id),
        FOREIGN KEY (papel_id) REFERENCES papel(id)
    );

    -- Tabela de Produtos com chaves estrangeiras
    CREATE TABLE produto (
        id INT AUTO_INCREMENT PRIMARY KEY,
        nome VARCHAR(255) NOT NULL,
        quantidade INT NOT NULL,
        preco DECIMAL(10, 2) NOT NULL,
        categoria_id INT,
        fornecedor_id INT,
        FOREIGN KEY (categoria_id) REFERENCES categoria(id),
        FOREIGN KEY (fornecedor_id) REFERENCES fornecedor(id)
    );