package br.com.aula.gestaodeestoques.dto;

import jakarta.validation.constraints.NotBlank;

/**
 * DTO for representing a Category in API requests and responses.
 */
public record CategoriaDTO(
    Integer id,

    @NotBlank(message = "O nome da categoria não pode ser vazio.")
    String nome
) {}
