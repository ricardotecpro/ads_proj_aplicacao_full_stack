package br.com.aula.gestaodeestoques;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GestaodeestoquesApplication {

	public static void main(String[] args) {
		SpringApplication.run(GestaodeestoquesApplication.class, args);
	}

}
