package br.com.aula.gestaodeestoques.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.PositiveOrZero;
import java.math.BigDecimal;

/**
 * DTO for representing a Product in API requests and responses.
 */
public record ProdutoDTO(
    Integer id,

    @NotBlank(message = "O nome do produto não pode ser vazio.")
    String nome,

    @NotNull(message = "A quantidade não pode ser nula.")
    @PositiveOrZero(message = "A quantidade deve ser zero ou maior.")
    Integer quantidade,

    @NotNull(message = "O preço não pode ser nulo.")
    @Positive(message = "O preço deve ser um valor positivo.")
    BigDecimal preco,

    @NotNull(message = "O ID da categoria é obrigatório.")
    Integer categoriaId,

    @NotNull(message = "O ID do fornecedor é obrigatório.")
    Integer fornecedorId
) {}
