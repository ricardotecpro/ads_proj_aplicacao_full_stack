package br.com.aula.gestaodeestoques.mapper;

import br.com.aula.gestaodeestoques.dto.ProdutoDTO;
import br.com.aula.gestaodeestoques.model.Produto;
import org.springframework.stereotype.Component;

@Component
public class ProdutoMapper {

    public ProdutoDTO toDto(Produto produto) {
        if (produto == null) {
            return null;
        }
        return new ProdutoDTO(
            produto.id(),
            produto.nome(),
            produto.quantidade(),
            produto.preco(),
            produto.categoriaId(),
            produto.fornecedorId()
        );
    }

    public Produto toEntity(ProdutoDTO produtoDTO) {
        if (produtoDTO == null) {
            return null;
        }
        return new Produto(
            produtoDTO.id(),
            produtoDTO.nome(),
            produtoDTO.quantidade(),
            produtoDTO.preco(),
            produtoDTO.categoriaId(),
            produtoDTO.fornecedorId()
        );
    }
}
