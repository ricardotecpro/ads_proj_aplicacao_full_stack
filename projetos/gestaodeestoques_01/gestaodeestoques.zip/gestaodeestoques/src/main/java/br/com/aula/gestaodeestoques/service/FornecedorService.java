package br.com.aula.gestaodeestoques.service;

import br.com.aula.gestaodeestoques.dto.FornecedorDTO;

import java.util.List;
import java.util.Optional;

public interface FornecedorService {

    List<FornecedorDTO> findAll();

    Optional<FornecedorDTO> findById(Integer id);

    FornecedorDTO save(FornecedorDTO fornecedorDTO);

    FornecedorDTO update(Integer id, FornecedorDTO fornecedorDTO);

    void deleteById(Integer id);
}
