package br.com.aula.gestaodeestoques.config;

import br.com.aula.gestaodeestoques.model.Papel;
import br.com.aula.gestaodeestoques.model.Usuario;
import br.com.aula.gestaodeestoques.repository.PapelRepository;
import br.com.aula.gestaodeestoques.repository.UsuarioRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.transaction.annotation.Transactional;

@Configuration
public class DataSeeder implements CommandLineRunner {

    private static final Logger logger = LoggerFactory.getLogger(DataSeeder.class);

    private final PapelRepository papelRepository;
    private final UsuarioRepository usuarioRepository;
    private final PasswordEncoder passwordEncoder;

    public DataSeeder(PapelRepository papelRepository, UsuarioRepository usuarioRepository, PasswordEncoder passwordEncoder) {
        this.papelRepository = papelRepository;
        this.usuarioRepository = usuarioRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    @Transactional
    public void run(String... args) throws Exception {
        if (usuarioRepository.count() == 0) {
            logger.info("Banco de dados vazio. Populando com dados iniciais...");

            // Criar papéis
            Papel adminPapel = papelRepository.save(new Papel(null, "ROLE_ADMIN"));
            Papel userPapel = papelRepository.save(new Papel(null, "ROLE_USER"));
            logger.info("Papéis criados: {}, {}", adminPapel, userPapel);

            // Criar usuários e capturar a instância retornada com o ID
            Usuario adminUser = new Usuario(null, "admin", passwordEncoder.encode("admin123"), true);
            Usuario savedAdmin = usuarioRepository.save(adminUser);
            logger.info("Usuário admin criado com ID: {}", savedAdmin.id());

            Usuario userUser = new Usuario(null, "user", passwordEncoder.encode("user123"), true);
            Usuario savedUser = usuarioRepository.save(userUser);
            logger.info("Usuário user criado com ID: {}", savedUser.id());

            // Associar usuários aos papéis usando o método do repositório
            usuarioRepository.adicionarPapel(savedAdmin.id(), adminPapel.id());
            logger.info("Papel ADMIN associado ao usuário admin.");

            usuarioRepository.adicionarPapel(savedUser.id(), userPapel.id());
            logger.info("Papel USER associado ao usuário user.");

            logger.info("População do banco de dados concluída com sucesso.");
        } else {
            logger.info("Banco de dados já populado. Nenhum dado foi inserido.");
        }
    }
}
