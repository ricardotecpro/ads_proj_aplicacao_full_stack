package br.com.aula.gestaodeestoques.dto;

// This class is deprecated and should be deleted.
public class ProdutoFormDTO {
}
