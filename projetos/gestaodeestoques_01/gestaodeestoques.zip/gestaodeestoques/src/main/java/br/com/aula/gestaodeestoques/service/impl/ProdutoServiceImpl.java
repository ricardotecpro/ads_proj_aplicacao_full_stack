package br.com.aula.gestaodeestoques.service.impl;

import br.com.aula.gestaodeestoques.dto.ProdutoDTO;
import br.com.aula.gestaodeestoques.exception.ResourceNotFoundException;
import br.com.aula.gestaodeestoques.mapper.ProdutoMapper;
import br.com.aula.gestaodeestoques.model.Categoria;
import br.com.aula.gestaodeestoques.model.Fornecedor;
import br.com.aula.gestaodeestoques.model.Produto;
import br.com.aula.gestaodeestoques.repository.CategoriaRepository;
import br.com.aula.gestaodeestoques.repository.FornecedorRepository;
import br.com.aula.gestaodeestoques.repository.ProdutoRepository;
import br.com.aula.gestaodeestoques.service.ProdutoService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

@Service
@Transactional
public class ProdutoServiceImpl implements ProdutoService {

    private final ProdutoRepository produtoRepository;
    private final CategoriaRepository categoriaRepository;
    private final FornecedorRepository fornecedorRepository;
    private final ProdutoMapper produtoMapper;

    public ProdutoServiceImpl(ProdutoRepository produtoRepository, CategoriaRepository categoriaRepository, FornecedorRepository fornecedorRepository, ProdutoMapper produtoMapper) {
        this.produtoRepository = produtoRepository;
        this.categoriaRepository = categoriaRepository;
        this.fornecedorRepository = fornecedorRepository;
        this.produtoMapper = produtoMapper;
    }

    @Override
    @Transactional(readOnly = true)
    public List<ProdutoDTO> findAll() {
        return StreamSupport.stream(produtoRepository.findAll().spliterator(), false)
                .map(produtoMapper::toDto)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<ProdutoDTO> findById(Integer id) {
        return produtoRepository.findById(id).map(produtoMapper::toDto);
    }

    @Override
    public ProdutoDTO save(ProdutoDTO produtoDTO) {
        Produto produto = produtoMapper.toEntity(produtoDTO);
        Produto savedProduto = produtoRepository.save(produto);
        return produtoMapper.toDto(savedProduto);
    }

    @Override
    public ProdutoDTO update(Integer id, ProdutoDTO produtoDTO) {
        Produto existingProduto = produtoRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Produto não encontrado com o ID: " + id));

        // Create a new record with the updated fields and the existing ID
        Produto updatedProduto = new Produto(
            existingProduto.id(),
            produtoDTO.nome(),
            produtoDTO.quantidade(),
            produtoDTO.preco(),
            produtoDTO.categoriaId(),
            produtoDTO.fornecedorId()
        );

        Produto savedProduto = produtoRepository.save(updatedProduto);
        return produtoMapper.toDto(savedProduto);
    }

    @Override
    public void deleteById(Integer id) {
        if (!produtoRepository.existsById(id)) {
            throw new ResourceNotFoundException("Produto não encontrado com o ID: " + id);
        }
        produtoRepository.deleteById(id);
    }

    @Override
    @Transactional(readOnly = true)
    public Iterable<Categoria> findAllCategorias() {
        return categoriaRepository.findAll();
    }

    @Override
    @Transactional(readOnly = true)
    public Iterable<Fornecedor> findAllFornecedores() {
        return fornecedorRepository.findAll();
    }
}
