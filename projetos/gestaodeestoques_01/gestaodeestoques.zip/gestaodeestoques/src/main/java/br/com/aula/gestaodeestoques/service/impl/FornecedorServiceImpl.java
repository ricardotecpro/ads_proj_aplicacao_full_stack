package br.com.aula.gestaodeestoques.service.impl;

import br.com.aula.gestaodeestoques.dto.FornecedorDTO;
import br.com.aula.gestaodeestoques.exception.ResourceNotFoundException;
import br.com.aula.gestaodeestoques.mapper.FornecedorMapper;
import br.com.aula.gestaodeestoques.model.Fornecedor;
import br.com.aula.gestaodeestoques.repository.FornecedorRepository;
import br.com.aula.gestaodeestoques.service.FornecedorService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

@Service
@Transactional
public class FornecedorServiceImpl implements FornecedorService {

    private final FornecedorRepository fornecedorRepository;
    private final FornecedorMapper fornecedorMapper;

    public FornecedorServiceImpl(FornecedorRepository fornecedorRepository, FornecedorMapper fornecedorMapper) {
        this.fornecedorRepository = fornecedorRepository;
        this.fornecedorMapper = fornecedorMapper;
    }

    @Override
    @Transactional(readOnly = true)
    public List<FornecedorDTO> findAll() {
        return StreamSupport.stream(fornecedorRepository.findAll().spliterator(), false)
                .map(fornecedorMapper::toDto)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<FornecedorDTO> findById(Integer id) {
        return fornecedorRepository.findById(id).map(fornecedorMapper::toDto);
    }

    @Override
    public FornecedorDTO save(FornecedorDTO fornecedorDTO) {
        Fornecedor fornecedor = fornecedorMapper.toEntity(fornecedorDTO);
        Fornecedor savedFornecedor = fornecedorRepository.save(fornecedor);
        return fornecedorMapper.toDto(savedFornecedor);
    }

    @Override
    public FornecedorDTO update(Integer id, FornecedorDTO fornecedorDTO) {
        Fornecedor existingFornecedor = fornecedorRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Fornecedor não encontrado com o ID: " + id));

        Fornecedor updatedFornecedor = new Fornecedor(existingFornecedor.id(), fornecedorDTO.nome(), fornecedorDTO.cnpj());
        Fornecedor savedFornecedor = fornecedorRepository.save(updatedFornecedor);
        return fornecedorMapper.toDto(savedFornecedor);
    }

    @Override
    public void deleteById(Integer id) {
        if (!fornecedorRepository.existsById(id)) {
            throw new ResourceNotFoundException("Fornecedor não encontrado com o ID: " + id);
        }
        fornecedorRepository.deleteById(id);
    }
}
