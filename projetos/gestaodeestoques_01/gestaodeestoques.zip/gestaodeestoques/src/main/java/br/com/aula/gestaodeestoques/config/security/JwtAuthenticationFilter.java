package br.com.aula.gestaodeestoques.config.security;

// This class is deprecated and should be deleted. It was part of the abandoned SPA architecture.
public class JwtAuthenticationFilter {
}
