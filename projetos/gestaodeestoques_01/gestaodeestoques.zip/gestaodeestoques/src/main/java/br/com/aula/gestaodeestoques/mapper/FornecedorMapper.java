package br.com.aula.gestaodeestoques.mapper;

import br.com.aula.gestaodeestoques.dto.FornecedorDTO;
import br.com.aula.gestaodeestoques.model.Fornecedor;
import org.springframework.stereotype.Component;

@Component
public class FornecedorMapper {

    public FornecedorDTO toDto(Fornecedor fornecedor) {
        if (fornecedor == null) {
            return null;
        }
        return new FornecedorDTO(fornecedor.id(), fornecedor.nome(), fornecedor.cnpj());
    }

    public Fornecedor toEntity(FornecedorDTO fornecedorDTO) {
        if (fornecedorDTO == null) {
            return null;
        }
        return new Fornecedor(fornecedorDTO.id(), fornecedorDTO.nome(), fornecedorDTO.cnpj());
    }
}
