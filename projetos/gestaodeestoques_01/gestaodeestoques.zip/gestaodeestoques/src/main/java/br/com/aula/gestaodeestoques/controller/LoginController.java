package br.com.aula.gestaodeestoques.controller;

// This class is deprecated and should be deleted. Its functionality is now handled by MvcConfig.
public class LoginController {
}
