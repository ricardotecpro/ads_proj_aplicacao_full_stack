package br.com.aula.gestaodeestoques.service;

import br.com.aula.gestaodeestoques.dto.CategoriaDTO;

import java.util.List;
import java.util.Optional;

public interface CategoriaService {

    List<CategoriaDTO> findAll();

    Optional<CategoriaDTO> findById(Integer id);

    CategoriaDTO save(CategoriaDTO categoriaDTO);

    CategoriaDTO update(Integer id, CategoriaDTO categoriaDTO);

    void deleteById(Integer id);
}
