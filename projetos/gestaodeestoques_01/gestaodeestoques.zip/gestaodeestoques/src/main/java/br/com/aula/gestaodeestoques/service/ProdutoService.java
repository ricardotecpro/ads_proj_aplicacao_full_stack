package br.com.aula.gestaodeestoques.service;

import br.com.aula.gestaodeestoques.dto.ProdutoDTO;
import br.com.aula.gestaodeestoques.model.Categoria;
import br.com.aula.gestaodeestoques.model.Fornecedor;

import java.util.List;
import java.util.Optional;

public interface ProdutoService {

    List<ProdutoDTO> findAll();

    Optional<ProdutoDTO> findById(Integer id);

    ProdutoDTO save(ProdutoDTO produtoDTO);

    ProdutoDTO update(Integer id, ProdutoDTO produtoDTO);

    void deleteById(Integer id);

    Iterable<Categoria> findAllCategorias();

    Iterable<Fornecedor> findAllFornecedores();
}
