package br.com.aula.gestaodeestoques.dto;

import jakarta.validation.constraints.NotBlank;

/**
 * DTO for representing a Supplier in API requests and responses.
 */
public record FornecedorDTO(
    Integer id,

    @NotBlank(message = "O nome do fornecedor não pode ser vazio.")
    String nome,

    @NotBlank(message = "O CNPJ do fornecedor não pode ser vazio.")
    String cnpj
) {}
