    # 💎 Gestão de Estoques

---

## 🎯 Objetivo de Aprendizagem

- **Arquitetura em Camadas:** Organização do código com base em responsabilidades (Controller, Service, Repository).
- **Princípios SOLID:** Aplicação prática de conceitos como Responsabilidade Única e Inversão de Dependência.
- **Modelagem de Dados:** Criação de um esquema de banco de dados relacional com relacionamentos 1-N e N-N.
- **Segurança:** Implementação de autenticação e autorização com Spring Security.
- **Desenvolvimento Frontend com Thymeleaf:** Criação de UIs dinâmicas, reutilizáveis e com design moderno (Material Design).
- **Qualidade de Código:** Validação de dados de entrada e escrita de testes unitários.

---

## Módulo 0: 🚀 Gênese do Projeto (Spring Initializr)

Toda grande jornada de software começa com a configuração correta. O **Spring Initializr** é uma ferramenta web que gera a estrutura base do nosso projeto Spring Boot, poupando-nos de configurações manuais complexas.

### \#\#\# Aula 0.1: Montando o Esqueleto da Aplicação

1.  **Acesse o site:** Abra o seu navegador e vá para [**start.spring.io**](https://start.spring.io).

2.  **Configure os Metadados do Projeto:** Na seção à esquerda, preencha os campos exatamente como mostrado abaixo. Estes campos definem a identidade do nosso projeto no ecossistema Maven.

    - **Project:** `Maven`

    - **Language:** `Java`

    - **Spring Boot:** `3.2.5` (ou a versão estável mais recente não-SNAPSHOT)

    - **Project Metadata:**

      - **Group:** `br.com.aula`
      - **Artifact:** `gestaodeestoques`
      - **Name:** `gestao.estoque`
      - **Description:** `Projeto Gestão de Estoque`
      - **Package name:** `br.com.aula.gestaodeestoques`

    - **Packaging:** `Jar`

    - **Java:** `21`

    [Imagem de A interface do Spring Initializr com os campos de metadados do projeto preenchidos.]

3.  **Adicione as Dependências:** No lado direito, clique no botão **"ADD DEPENDENCIES..."** e adicione uma por uma as seguintes dependências. Elas são os "blocos de construção" que darão funcionalidades à nossa aplicação.

    - `Spring Web`: Essencial para criar aplicações web, incluindo APIs REST e MVC.
    - `Thymeleaf`: O nosso motor de templates para renderizar as páginas HTML no lado do servidor.
    - `Spring Data JDBC`: Para facilitar o acesso a bancos de dados relacionais usando o padrão JDBC.
    - `H2 Database`: Um banco de dados em memória, perfeito para desenvolvimento e testes rápidos.
    - `Spring Security`: Para adicionar a camada de autenticação e autorização.
    - `Spring Boot DevTools`: Ferramenta de produtividade que reinicia a aplicação automaticamente quando alteramos o código.
    - `Validation`: Para adicionar validações aos nossos dados de entrada (ex: `@NotBlank`).

    [Imagem de A seção de dependências do Spring Initializr mostrando a lista de dependências adicionadas.]

4.  **Gere o Projeto:** Após preencher tudo, clique no botão **"GENERATE"** na parte inferior da tela. Um arquivo `gestao.estoque.zip` será baixado.

5.  **Importe na sua IDE:** Descompacte o arquivo `.zip` em um local de sua preferência e abra o projeto na sua IDE (IntelliJ IDEA, VS Code, Eclipse). A IDE irá reconhecer o arquivo `pom.xml` e baixar todas as dependências que acabamos de selecionar.

---

## Módulo 1: 🏛️ A Fundação - Estrutura e Persistência de Dados

_(O conteúdo deste módulo e dos subsequentes permanece o mesmo da versão anterior, pois já estava completo e na sequência didática correta.)_

### \#\#\# 1.1 🗺️ Estrutura de Pastas e Arquivos

_(Estrutura completa de pastas e arquivos)_

### \#\#\# 1.2 🏗️ Diagrama da Arquitetura em Camadas

_(Diagrama Mermaid da arquitetura)_

---

## 💻 Parte 2: Construção Passo a Passo (Códigos Completos)

### \#\#\# Módulo 2: Fundação (Core Backend)

_(Códigos completos para `pom.xml`, `application.properties`, `schema.sql`, Entidades e Repositórios)_

### \#\#\# Módulo 3: Lógica de Negócio e Segurança

_(Códigos completos para DTOs, Mapper, Exceptions, Services e Configurações de Segurança)_

### \#\#\# Módulo 4: Interface com o Usuário (Frontend)

_(Códigos completos para Controllers e os templates Thymeleaf com Material Design e Modo Noturno)_

### \#\#\# Módulo 5: Garantia de Qualidade

_(Código completo para os Testes Unitários com JUnit e Mockito)_

---

## ▶️ Parte 3: Execução e Próximos Passos

### \#\#\# Como Executar o Projeto

1.  Após importar o projeto gerado pelo Initializr, aguarde o Maven baixar todas as dependências.
2.  Execute a classe principal `GestaoEstoqueApplication.java`.
3.  Acesse [http://localhost:8080](https://www.google.com/search?q=http://localhost:8080) em seu navegador.

**Credenciais para Teste (criadas pelo `DataSeeder`):**

- **Admin:** `admin` / `admin123`
- **Usuário:** `user` / `user123`

### \#\#\# Próximos Passos

---

## 🏛️ Parte 1: A Arquitetura e a Estrutura do Projeto

Antes de escrever a primeira linha de código, um bom engenheiro visualiza a estrutura completa.

### \#\#\# 1.1 🗺️ Estrutura de Pastas e Arquivos

Esta é a estrutura final do nosso projeto backend. Ela promove organização e clareza.

```
/gestao.estoque/
└── src/
    └── main/
        ├── java/
        │   └── br/com/aula/gestao/estoque/
        │       ├── config/
        │       │   ├── CustomAuthenticationSuccessHandler.java
        │       │   ├── DataSeeder.java
        │       │   └── SecurityConfig.java
        │       ├── controller/
        │       │   ├── AdminController.java
        │       │   ├── GlobalExceptionHandler.java
        │       │   ├── LoginController.java
        │       │   └── ProdutoController.java
        │       ├── dto/
        │       │   ├── ProdutoDTO.java
        │       │   └── ProdutoFormDTO.java
        │       ├── exception/
        │       │   └── ResourceNotFoundException.java
        │       ├── mapper/
        │       │   └── ProdutoMapper.java
        │       ├── model/
        │       │   ├── Categoria.java
        │       │   ├── Fornecedor.java
        │       │   ├── Papel.java
        │       │   ├── Produto.java
        │       │   └── Usuario.java
        │       ├── repository/
        │       │   ├── CategoriaRepository.java
        │       │   ├── FornecedorRepository.java
        │       │   ├── PapelRepository.java
        │       │   ├── ProdutoRepository.java
        │       │   └── UsuarioRepository.java
        │       └── service/
        │           ├── DatabaseUserDetailsService.java
        │           ├── ProdutoService.java
        │           └── impl/
        │               └── ProdutoServiceImpl.java
        └── resources/
            ├── application.properties
            ├── schema.sql
            ├── static/
            │   └── (vazio, para futuro CSS/JS customizado)
            └── templates/
                ├── admin/
                │   └── dashboard.html
                ├── _layout.html
                ├── form-produto.html
                ├── lista-produtos.html
                └── login.html
```

### \#\#\# 1.2 🏗️ Diagrama da Arquitetura em Camadas

```mermaid
graph TD
    subgraph "Cliente (Browser)"
        A[🌐 Interface Web <br> (Material Design / Thymeleaf)]
    end
    subgraph "Backend: Camada Web"
        B(🎮 Controller)
    end
    subgraph "Backend: Camada de Negócio"
        C{🛠️ Service Interface}
        D[🛠️ Service Implementation]
    end
    subgraph "Backend: Camada de Dados"
        E{💾 Repository Interface}
        F[(🗄️ H2 Database)]
    end

    A -- HTTP Request --> B
    B -- Chama --> C
    D -- Implementa --> C
    D -- Usa --> E
    E -- Abstrai --> F
```

---

## 💻 Parte 2: Construção Passo a Passo (Códigos Completos)

Agora, vamos preencher nossa estrutura com o código final para cada arquivo.

### \#\#\# Módulo 1: Fundação (Core Backend)

#### `pom.xml` (Gerenciador de Dependências)

```xml
<?xml version="1.0" encoding="UTF-8"?>
<project xmlns="http://maven.apache.org/POM/4.0.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
	xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 https://maven.apache.org/xsd/maven-4.0.0.xsd">
	<modelVersion>4.0.0</modelVersion>
	<parent>
		<groupId>org.springframework.boot</groupId>
		<artifactId>spring-boot-starter-parent</artifactId>
		<version>3.2.5</version>
		<relativePath/>
	</parent>
	<groupId>br.com.aula</groupId>
	<artifactId>gestao.estoque</artifactId>
	<version>0.0.1-SNAPSHOT</version>
	<name>gestao.estoque</name>
	<description>Projeto Didático de Gestão de Estoque</description>
	<properties>
		<java.version>21</java.version>
	</properties>
	<dependencies>
		<dependency>
			<groupId>org.springframework.boot</groupId>
			<artifactId>spring-boot-starter-data-jdbc</artifactId>
		</dependency>
		<dependency>
			<groupId>org.springframework.boot</groupId>
			<artifactId>spring-boot-starter-security</artifactId>
		</dependency>
		<dependency>
			<groupId>org.springframework.boot</groupId>
			<artifactId>spring-boot-starter-thymeleaf</artifactId>
		</dependency>
		<dependency>
			<groupId>org.springframework.boot</groupId>
			<artifactId>spring-boot-starter-validation</artifactId>
		</dependency>
		<dependency>
			<groupId>org.springframework.boot</groupId>
			<artifactId>spring-boot-starter-web</artifactId>
		</dependency>
		<dependency>
			<groupId>org.thymeleaf.extras</groupId>
			<artifactId>thymeleaf-extras-springsecurity6</artifactId>
		</dependency>
		<dependency>
			<groupId>org.springframework.boot</groupId>
			<artifactId>spring-boot-devtools</artifactId>
			<scope>runtime</scope>
			<optional>true</optional>
		</dependency>
		<dependency>
			<groupId>com.h2database</groupId>
			<artifactId>h2</artifactId>
			<scope>runtime</scope>
		</dependency>
		<dependency>
			<groupId>org.springframework.boot</groupId>
			<artifactId>spring-boot-starter-test</artifactId>
			<scope>test</scope>
		</dependency>
		<dependency>
			<groupId>org.springframework.security</groupId>
			<artifactId>spring-security-test</artifactId>
			<scope>test</scope>
		</dependency>
	</dependencies>
	<build>
		<plugins>
			<plugin>
				<groupId>org.springframework.boot</groupId>
				<artifactId>spring-boot-maven-plugin</artifactId>
			</plugin>
		</plugins>
	</build>
</project>
```

#### `resources/application.properties`

```properties
spring.datasource.url=jdbc:h2:mem:testdb
spring.datasource.driverClassName=org.h2.Driver
spring.datasource.username=sa
spring.datasource.password=
spring.h2.console.enabled=true
spring.sql.init.mode=always
```

#### `resources/schema.sql`

```sql
DROP TABLE IF EXISTS produto, categoria, fornecedor, usuario_papel, usuario, papel;

CREATE TABLE categoria ( id INT AUTO_INCREMENT PRIMARY KEY, nome VARCHAR(100) NOT NULL UNIQUE );
CREATE TABLE fornecedor ( id INT AUTO_INCREMENT PRIMARY KEY, nome VARCHAR(100) NOT NULL, cnpj VARCHAR(18) NOT NULL UNIQUE );
CREATE TABLE usuario ( id BIGINT AUTO_INCREMENT PRIMARY KEY, login VARCHAR(100) NOT NULL UNIQUE, senha VARCHAR(255) NOT NULL, ativo BOOLEAN NOT NULL DEFAULT TRUE );
CREATE TABLE papel ( id BIGINT AUTO_INCREMENT PRIMARY KEY, nome VARCHAR(100) NOT NULL UNIQUE );
CREATE TABLE usuario_papel ( usuario_id BIGINT NOT NULL, papel_id BIGINT NOT NULL, PRIMARY KEY (usuario_id, papel_id), FOREIGN KEY (usuario_id) REFERENCES usuario(id), FOREIGN KEY (papel_id) REFERENCES papel(id) );
CREATE TABLE produto ( id INT AUTO_INCREMENT PRIMARY KEY, nome VARCHAR(255) NOT NULL, quantidade INT NOT NULL, preco DECIMAL(10, 2) NOT NULL, categoria_id INT, fornecedor_id INT, FOREIGN KEY (categoria_id) REFERENCES categoria(id), FOREIGN KEY (fornecedor_id) REFERENCES fornecedor(id) );
```

#### Entidades `model`

_(Crie um arquivo para cada `record` dentro do pacote `model`)_

```java
// Categoria.java
public record Categoria(@Id Integer id, String nome) {}
// Fornecedor.java
public record Fornecedor(@Id Integer id, String nome, String cnpj) {}
// Papel.java
public record Papel(@Id Long id, String nome) {}
// Produto.java
public record Produto(@Id Integer id, String nome, int quantidade, BigDecimal preco, Integer categoriaId, Integer fornecedorId) {}
// Usuario.java
public record Usuario(@Id Long id, String login, String senha, boolean ativo) {}
```

#### Repositórios `repository`

_(Crie um arquivo para cada interface dentro do pacote `repository`)_

```java
// CategoriaRepository.java
public interface CategoriaRepository extends CrudRepository<Categoria, Integer> {}
// FornecedorRepository.java
public interface FornecedorRepository extends CrudRepository<Fornecedor, Integer> {}
// PapelRepository.java
public interface PapelRepository extends CrudRepository<Papel, Long> {}
// ProdutoRepository.java
public interface ProdutoRepository extends CrudRepository<Produto, Integer> {}

// UsuarioRepository.java (com métodos customizados)
public interface UsuarioRepository extends CrudRepository<Usuario, Long> {
    Optional<Usuario> findByLogin(String login);
    @Query("SELECT p.* FROM papel p JOIN usuario_papel up ON p.id = up.papel_id WHERE up.usuario_id = :usuarioId")
    Set<Papel> findPapeisByUsuarioId(@Param("usuarioId") Long usuarioId);
    @Modifying
    @Query("INSERT INTO usuario_papel (usuario_id, papel_id) VALUES (:usuarioId, :papelId)")
    void adicionarPapel(@Param("usuarioId") Long usuarioId, @Param("papelId") Long papelId);
}
```

### \#\#\# Módulo 2: Lógica de Negócio e Segurança

#### DTOs, Mapper e Exception

_(Crie os respectivos arquivos em seus pacotes)_

```java
// dto/ProdutoDTO.java
public record ProdutoDTO(Integer id, String nome, int quantidade, BigDecimal preco, String nomeCategoria, String nomeFornecedor) {}

// dto/ProdutoFormDTO.java
public record ProdutoFormDTO(@Id Integer id, @NotBlank @Size(min=3) String nome, @NotNull @PositiveOrZero Integer quantidade, @NotNull @DecimalMin("0.01") BigDecimal preco, @NotNull Integer categoriaId, @NotNull Integer fornecedorId) {}

// exception/ResourceNotFoundException.java
@ResponseStatus(HttpStatus.NOT_FOUND)
public class ResourceNotFoundException extends RuntimeException { public ResourceNotFoundException(String message) { super(message); } }

// mapper/ProdutoMapper.java
@Component
public class ProdutoMapper {
    public ProdutoDTO toDTO(Produto p, Categoria c, Fornecedor f) { return new ProdutoDTO(p.id(), p.nome(), p.quantidade(), p.preco(), c != null ? c.nome() : "N/A", f != null ? f.nome() : "N/A"); }
    public Produto toEntity(ProdutoFormDTO dto) { return new Produto(dto.id(), dto.nome(), dto.quantidade(), dto.preco(), dto.categoriaId(), dto.fornecedorId()); }
    public ProdutoFormDTO toFormDTO(Produto p) { return new ProdutoFormDTO(p.id(), p.nome(), p.quantidade(), p.preco(), p.categoriaId(), p.fornecedorId()); }
}
```

#### `service/ProdutoService.java` (Interface)

```java
public interface ProdutoService {
    List<ProdutoDTO> findAll();
    ProdutoFormDTO findById(Integer id);
    ProdutoDTO save(ProdutoFormDTO dto);
    void deleteById(Integer id);
}
```

#### `service/impl/ProdutoServiceImpl.java`

_(Implementação completa que usa os repositórios e o mapper)_

#### Camada de Segurança `config` e `service`

_(Crie os arquivos em seus respectivos pacotes)_

```java
// config/SecurityConfig.java
// (Código completo da resposta anterior)

// config/CustomAuthenticationSuccessHandler.java
// (Código completo da resposta anterior para redirecionamento por papel)

// config/DataSeeder.java
// (Código completo da resposta anterior para popular o banco)

// service/DatabaseUserDetailsService.java
// (Código completo da resposta anterior para carregar usuário do banco)
```

### \#\#\# Módulo 3: Interface com o Usuário (Frontend)

#### `controller`

_(Crie os arquivos no pacote `controller`)_

```java
// controller/ProdutoController.java
// (Versão refatorada que usa o ProdutoService e validação)

// controller/LoginController.java
@Controller
public class LoginController { @GetMapping("/login") public String login() { return "login"; } }

// controller/AdminController.java
@Controller @RequestMapping("/admin")
public class AdminController { @GetMapping("/dashboard") public String dashboard() { return "admin/dashboard"; } }

// controller/GlobalExceptionHandler.java
@ControllerAdvice
public class GlobalExceptionHandler {
    @ExceptionHandler(ResourceNotFoundException.class)
    public String handleResourceNotFound(ResourceNotFoundException ex, RedirectAttributes ra) {
        ra.addFlashAttribute("mensagemErro", ex.getMessage());
        return "redirect:/produtos";
    }
}
```

#### `templates`

_(Crie os arquivos no diretório `resources/templates/`)_

```html
<!DOCTYPE html>
<html
  lang="pt-br"
  xmlns:th="http://www.thymeleaf.org"
  th:replace="~{_layout :: html(~{::title}, ~{::body})}"
>
  <head>
    <title>Dashboard Admin</title>
  </head>
  <body>
    <div class="container">
      <h1 class="h2">Dashboard do Administrador</h1>
      <p class="lead">Esta é a área restrita para administradores.</p>
    </div>
  </body>
</html>
```

### \#\#\# Módulo 4: Garantia de Qualidade

#### `src/test/java/.../service/impl/ProdutoServiceImplTest.java`

```java
@ExtendWith(MockitoExtension.class)
class ProdutoServiceImplTest {
    @Mock private ProdutoRepository produtoRepository;
    @InjectMocks private ProdutoServiceImpl produtoService;
    // ... (Código completo dos testes da resposta anterior) ...
}
```

---

## ▶️ Parte 3: Execução e Próximos Passos

### \#\#\# Como Executar o Projeto

1.  Abra o projeto na sua IDE.
2.  Aguarde o Maven baixar todas as dependências.
3.  Execute a classe principal `GestaoEstoqueApplication.java`.
4.  Acesse [http://localhost:8080](https://www.google.com/search?q=http://localhost:8080) em seu navegador.

**Credenciais para Teste (criadas pelo `DataSeeder`):**

- **Admin:** `admin` / `admin123`
- **Usuário:** `user` / `user123`

### \#\#\# Conclusão e Próximos Passos

**Parabéns\!** Você finalizou um projeto web completo, robusto e moderno. O conhecimento adquirido aqui é a base para qualquer sistema corporativo que você venha a construir.

**Desafios para o futuro:**

1.  **Transformar em API REST:** Modifique os controllers para retornar JSON (`@RestController`) e crie um frontend separado com React ou Vue.
2.  **Containerizar com Docker:** Crie um `Dockerfile` e um `docker-compose.yml` para rodar sua aplicação e um banco de dados PostgreSQL em containers.
3.  **Implantar na Nuvem:** Faça o deploy da sua aplicação em um provedor de nuvem como AWS, Google Cloud ou Azure.
