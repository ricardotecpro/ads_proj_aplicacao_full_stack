package br.com.controledegastos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ControleDeGastosApplicationTests {

	@Test
	void contextLoads() {
	}

}
